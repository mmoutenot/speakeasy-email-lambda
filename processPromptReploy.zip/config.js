﻿"use strict";

var config = {
  "templateBucket": "speakeasy-email-templates",
  "templateKey": "test.html",
  "targetAddress": "mmoutenot@gmail.com",
  "fromAddress": "Speakeasy <mmoutenot@gmail.com>"
}

module.exports = config
